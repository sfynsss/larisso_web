<?php

namespace Larisso\Http\Controllers;

use Illuminate\Http\Request;

class SettingController extends Controller
{
    //
}
