<?php

namespace Larisso;

use Illuminate\Database\Eloquent\Model;

class TukarVoucher extends Model
{
    protected $table = "tukar_voucher";

    public $timestamps = false;
}
