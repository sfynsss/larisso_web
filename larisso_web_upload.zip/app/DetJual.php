<?php

namespace Larisso;

use Illuminate\Database\Eloquent\Model;

class DetJual extends Model
{
    protected $table = "det_jual";

	public $timestamps = false;
}
