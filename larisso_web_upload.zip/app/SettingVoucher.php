<?php

namespace Larisso;

use Illuminate\Database\Eloquent\Model;

class SettingVoucher extends Model
{
    protected $table = "setting_voucher";

    public $timestamps = false;
}
