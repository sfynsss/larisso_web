<?php

namespace Larisso;

use Illuminate\Database\Eloquent\Model;

class vw_laba_kotor extends Model
{
    protected $table = "vw_laba_kotor";
}
