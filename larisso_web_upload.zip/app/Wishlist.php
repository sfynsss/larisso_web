<?php

namespace Larisso;

use Illuminate\Database\Eloquent\Model;

class Wishlist extends Model
{
    protected $table = "wishlist";
    
    public $timestamps = false;
}
