<?php

namespace Larisso;

use Illuminate\Database\Eloquent\Model;

class OngkirCod extends Model
{
    protected $table 	= 'ongkir_cod';
    protected $guarded	= [];

    public $timestamps = false;
}
