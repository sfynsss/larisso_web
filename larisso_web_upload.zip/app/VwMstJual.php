<?php

namespace Larisso;

use Illuminate\Database\Eloquent\Model;

class VwMstJual extends Model
{
    protected $table = "vw_mst_jual";

    public $timestamps = false;
}
