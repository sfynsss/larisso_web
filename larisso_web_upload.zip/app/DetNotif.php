<?php

namespace Larisso;

use Illuminate\Database\Eloquent\Model;

class DetNotif extends Model
{
    protected $table = "det_notif";

    public $timestamps = false;
}
