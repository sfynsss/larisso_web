<?php

namespace Larisso;

use Illuminate\Database\Eloquent\Model;

class Notif extends Model
{
    protected $table = "notif";

    public $timestamps = false;
}
