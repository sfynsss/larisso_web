<?php

namespace Larisso;

use Illuminate\Database\Eloquent\Model;

class AuthAndroid extends Model
{
	protected $table = "auth_android";

	public $timestamps = false;
}
