<?php

namespace Larisso;

use Illuminate\Database\Eloquent\Model;

class MstVoucher extends Model
{
    protected $table = "mst_voucher";

    public $timestamps = false;
}
