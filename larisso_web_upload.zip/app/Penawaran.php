<?php

namespace Larisso;

use Illuminate\Database\Eloquent\Model;

class Penawaran extends Model
{
    protected $table = "penawaran";

    public $timestamps = false;
}
