<?php

namespace Larisso;

use Illuminate\Database\Eloquent\Model;

class DetVoucher extends Model
{
    protected $table = "det_voucher";

    public $timestamps = false;
}
