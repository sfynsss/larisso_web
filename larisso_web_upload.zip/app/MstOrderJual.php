<?php

namespace Larisso;

use Illuminate\Database\Eloquent\Model;

class MstOrderJual extends Model
{
    protected $table = "mst_ord_jual_mob";

    public $timestamps = false;
}
