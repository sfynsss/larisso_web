<?php

namespace Larisso;

use Illuminate\Database\Eloquent\Model;

class Kunjungan extends Model
{
    protected $table = "kunjungan";

    public $timestamps = false;
}
