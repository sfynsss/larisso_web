<?php

namespace Larisso;

use Illuminate\Database\Eloquent\Model;

class KategoriOutlet extends Model
{
    protected $table = "kat_outlet";

    public $timestamps = false;
}
