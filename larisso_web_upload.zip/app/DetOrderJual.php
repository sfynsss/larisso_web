<?php

namespace Larisso;

use Illuminate\Database\Eloquent\Model;

class DetOrderJual extends Model
{
    protected $table = "det_ord_jual_mob";

    public $timestamps = false;
}
