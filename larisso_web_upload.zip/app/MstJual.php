<?php

namespace Larisso;

use Illuminate\Database\Eloquent\Model;

class MstJual extends Model
{
    protected $table = "mst_jual";

	public $timestamps = false;
}
