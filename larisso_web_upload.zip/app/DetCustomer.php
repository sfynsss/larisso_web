<?php

namespace Larisso;

use Illuminate\Database\Eloquent\Model;

class DetCustomer extends Model
{
    protected $table = "det_customer";

	public $timestamps = false;
}
