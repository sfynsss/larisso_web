<?php

namespace Larisso;

use Illuminate\Database\Eloquent\Model;

class Alamat extends Model
{
    protected $table = "alamat";

    public $timestamps = false;
}
