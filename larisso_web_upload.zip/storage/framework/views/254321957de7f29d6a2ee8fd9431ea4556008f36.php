<?php $__env->startSection('content'); ?>

<section id="wrapper" class="error-page">
	<div class="error-body text-center">
		<h1><?php echo e($data); ?></h1>
		<h3 class="text-uppercase" style="color: black;"> <?php echo e($data1); ?></h3>
		
		
		<footer class="footer text-center">© 2021 Larisso Group.</footer>
	</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.attr2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KANTOR\WEB\larisso_web\resources\views/auth/verify-success.blade.php ENDPATH**/ ?>