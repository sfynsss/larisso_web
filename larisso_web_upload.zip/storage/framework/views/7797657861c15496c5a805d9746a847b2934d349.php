[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH D:\Kantor\SISTEM\SENYUM_VOUCHER\senyum_api\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>