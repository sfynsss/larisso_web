<?php echo e($slot); ?>

<?php /**PATH /home/asarasai/public_html/larisso_web/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>