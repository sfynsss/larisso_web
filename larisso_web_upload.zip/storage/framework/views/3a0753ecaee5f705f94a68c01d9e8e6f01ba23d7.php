<?php echo e($slot); ?>

<?php /**PATH D:\Kantor\SISTEM\SENYUM_VOUCHER\senyum_api\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>