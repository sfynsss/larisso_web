<tr>
    <td>
        <table class="footer" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
            <tr>
                <td class="content-cell" align="center">
                    
                    © 2020 Senyum Media. All rights reserved.
                </td>
            </tr>
        </table>
    </td>
</tr>
<?php /**PATH D:\Kantor\SISTEM\SENYUM_VOUCHER\senyum_api\resources\views/vendor/mail/html/footer.blade.php ENDPATH**/ ?>