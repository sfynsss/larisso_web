[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /home/asarasai/public_html/larisso_web/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>