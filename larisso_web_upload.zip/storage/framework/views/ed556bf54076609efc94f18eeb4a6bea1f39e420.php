<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-body">
        
        <div class="row">
            <div class="col-md-4"><h4 class="card-title">Data Customer</h4></div>
            <div class="col-md-8 form-group">
                
                    <button type="button" class="btn btn-primary float-right" data-toggle="modal"  data-target=".bs-example-modal-lg">TAMBAH DATA</button>
                    <a href="<?php echo e(url('/sinkronisasi')); ?>"><button type="button" class="btn btn-success float-right" style="margin-right: 10px;">SINKRONISASI</button></a>
                    
                
            </div>
        </div>


        <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
            <div class="modal-dialog modal-lg">
                <form action="<?php echo e(url('/tambahCustomer')); ?>" method="post" class="form-horizontal">
                    <?php echo e(csrf_field()); ?>

                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="myLargeModalLabel">Form Tambah Customer</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        </div>
                        <div class="modal-body">
                            <div class="card-body">
                                <div class="form-body">
                                    <h3 class="box-title">Master Customer</h3>
                                    <hr class="m-t-0 m-b-40">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group has-warning row">
                                                <label class="control-label text-left col-md-4">Pilih Cabang</label>
                                                <div class="col-md-8">
                                                    <select id="cabang" name="cabang" onchange="setKdCust();" class="form-control custom-select">
                                                        <option style="display: none;">Select an Option</option>
                                                        <?php $__currentLoopData = $cabang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cabang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($cabang->cabang); ?>"><?php echo e($cabang->cabang); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <!--/span-->
                                        <div class="col-md-6">
                                            <div class="form-group has-warning row">
                                                <label class="control-label text-left col-md-4">Kategori</label>
                                                <div class="col-md-8">
                                                    <select id="kategori" name="kategori" onchange="setKdCust();" class="form-control custom-select">
                                                        <option style="display: none;">Select an Option</option>
                                                        <?php $__currentLoopData = $kategori_customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($kat->KD_KAT); ?>"><?php echo e($kat->KATEGORI); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <!--/span-->
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="control-label text-left col-md-4">Kode Customer</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" readonly name="kode_cust" id="kode_cust">
                                                </div>
                                            </div>
                                        </div>
                                        <!--/span-->
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="control-label text-left col-md-4">NIK</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" min="16" max="16" name="nik" id="nik">
                                                </div>
                                            </div>
                                        </div>
                                        <!--/span-->
                                    </div>

                                    <h3 class="box-title">Customer Info</h3>
                                    <hr class="m-t-0 m-b-40">
                                    <!--/row-->
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="control-label text-left col-md-4">Nama</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="name" name="name">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="control-label text-left col-md-4">Alamat</label>
                                                <div class="col-md-8">
                                                    <input type="text" id="alamat" name="alamat" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="control-label text-left col-md-4">Tgl Lahir</label>
                                                <div class="col-md-8">
                                                    <input type="date" name="tgl_lahir" id="tgl_lahir" class="form-control" placeholder="dd/mm/yyyy">
                                                </div>
                                            </div>
                                        </div>
                                        <!--/span-->
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="control-label text-left col-md-4">Kota / Wilayah</label>
                                                <div class="col-md-8">
                                                    <select id="kota" name="kota" class="form-control custom-select">
                                                        <option style="display: none;">Select an Option</option>
                                                        <?php $__currentLoopData = $wilayah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($wil->KD_WIL); ?>.<?php echo e($wil->WILAYAH); ?>"><?php echo e($wil->WILAYAH); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <!--/span-->
                                    </div>
                                    <!--/row-->
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="control-label text-left col-md-4">No Telp / Hp</label>
                                                <div class="col-md-8">
                                                    <input type="text" id="no_telp" name="no_telp" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <!--/span-->
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="control-label text-left col-md-4">Jenis Kelamin</label>
                                                <div class="col-md-8">
                                                    <select name="jenis_kelamin" class="form-control custom-select">
                                                        <option value="Laki-laki">Laki - Laki</option>
                                                        <option value="Perempuan">Perempuan</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <!--/span-->
                                    </div>
                                    <!--/row-->
                                    <h3 class="box-title">Detail Customer</h3>
                                    <hr class="m-t-0 m-b-40">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="control-label text-left col-md-4">Email</label>
                                                <div class="col-md-8">
                                                    <input type="Email" id="email" name="email" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <!--/span-->
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="control-label text-left col-md-4">Kredit Limit</label>
                                                <div class="col-md-8">
                                                    <input type="number" id="kredit_limit" name="kredit_limit" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <!--/span-->
                                    </div>
                                    <!--/row-->
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="control-label text-left col-md-4">TOP (Termin)</label>
                                                <div class="col-md-8">
                                                    <input type="number" id="top" name="top" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <!--/span-->
                                    </div>
                                    <!--/row-->
                                </div>
                                
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger waves-effect text-left" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-success waves-effect text-left">Submit</button>
                        </div>
                    </div>
                </form>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>

        <div class="modal fade modal_detail" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="myLargeModalLabel">Detail Customer</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>
                    <div class="modal-body"></div>
                    <div class="modal-footer">
                    </div>
                </div>
            </div>
        </div>

        <div class="table-responsive m-t-40">
            <table id="myTable" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Kode Cust</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>No Hp</th>
                        <th>Email</th>
                        <th>Cabang</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($data->KD_CUST); ?></td>
                        <td><?php echo e($data->NM_CUST); ?></td>
                        <td><?php echo e($data->ALM_CUST); ?></td>
                        <td><?php echo e($data->HP); ?></td>
                        <td><?php echo e($data->E_MAIL); ?></td>
                        <td><?php echo e($data->CABANG); ?></td>
                        <td>
                            <a class="label label-info m-r-10" href="" data-toggle="modal"  data-target=".modal_detail"><i class="mdi mdi-eye"></i></a>
                            <a class="label label-primary m-r-10" href="" data-toggle="modal"  data-target=".bs-example-modal-lg" onclick="setIsi(<?php echo e($data->CABANG); ?>, <?php echo e($data->KD_KAT); ?>, <?php echo e($data->KD_CUST); ?>, <?php echo e($data->NIK); ?>, <?php echo e($data->NM_CUST); ?>);"><i class="mdi mdi-pencil"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>

    function setKdCust() {
        var kategori = $("select[name=kategori]").val();
        var cabang = $("select[name=cabang]").val();
        // alert(kategori+" | "+cabang);
        if (kategori == "Select an Option" || cabang == "Select an Option") {

        } else {
            $.ajax({
             type:'POST',
             url:'/api/getKodeCust',
             data:{kategori:kategori, cabang:cabang},
             headers: {
                "Accept":"application/json",
                "Authorization":"Bearer <?php echo e(Auth::user()->api_token); ?>"
            },
            success:function(data){
              $("input[name=kode_cust]").val(data);
              // alert(data);
          }
      });
        }
    }

    function setIsi() {

    }

    // window.RTCPeerConnection = window.RTCPeerConnection || window.mozRTCPeerConnection || window.webkitRTCPeerConnection;//compatibility for Firefox and chrome
    // var pc = new RTCPeerConnection({iceServers:[]}), noop = function(){};      
    // pc.createDataChannel('');//create a bogus data channel
    // pc.createOffer(pc.setLocalDescription.bind(pc), noop);// create offer and set local description
    // pc.onicecandidate = function(ice) {
    //     if (ice && ice.candidate && ice.candidate.candidate) {
    //         var myIP = /([0-9]{1,3}(\.[0-9]{1,3}){3}|[a-f0-9]{1,4}(:[a-f0-9]{1,4}){7})/.exec(ice.candidate.candidate)[1];  
    //         pc.onicecandidate = noop;
    //         // alert(myIP);
    //         document.getElementById("link_download").setAttribute("href", '<?php echo e(url('/downloadCustomer')); ?>/'+myIP);
    //     }
    // };

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.attr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kantor\SISTEM\SENYUM_VOUCHER\senyum_api\resources\views/Customer/customer.blade.php ENDPATH**/ ?>