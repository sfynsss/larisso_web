<?php $__env->startSection('content'); ?>

<div class="nk-block nk-block-lg">
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title">Master Outlet</h3>
            </div><!-- .nk-block-head-content -->
            <div class="nk-block-head-content">
                <div class="toggle-wrap nk-block-tools-toggle">
                    <button class="btn btn-primary" data-toggle="modal" data-target=".modal_input" onclick="setKodeOutlet();">Tambah</button> 
                </div>
            </div><!-- .nk-block-head-content -->
        </div><!-- .nk-block-between -->
    </div><!-- .nk-block-head -->

    <div class="modal fade modal_input" id="modalku" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
        <div class="modal-dialog modal-lg">
            <form action="<?php echo e(url('/tambahOutlet')); ?>" method="post" id="link_url" name="link_url" class="form-horizontal">
                <?php echo e(csrf_field()); ?>

                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="myLargeModalLabel">Form Outlet</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>
                    <div class="modal-body">
                        <div class="card-inner">
                            <div class="row g-4">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label class="form-label" for="full-name-1">Kode Outlet</label>
                                        <div class="form-control-wrap">
                                            <input type="text" class="form-control" id="kd_outlet" name="kd_outlet" readonly>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label class="form-label" for="full-name-1">Nama Outlet</label>
                                        <div class="form-control-wrap">
                                            <input type="text" class="form-control" id="nama_outlet" name="nama_outlet">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label class="form-label" for="email-address-1">Keterangan</label>
                                        <div class="form-control-wrap">
                                            <input type="text" class="form-control" id="keterangan" name="keterangan">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label class="form-label">Status Aktif</label>
                                        <ul class="custom-control-group g-3 align-center">
                                            <li>
                                                <div class="custom-control custom-control-sm custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="status" name="status" value="1">
                                                    <label class="custom-control-label" for="status">Aktif</label>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger waves-effect text-left">Close</button>
                        <button type="submit" class="btn btn-success waves-effect text-left">Submit</button>
                    </div>
                </div>
            </form>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>

    <div class="card card-bordered card-preview">
        <table class="table table-orders">
            <thead class="tb-odr-head">
                <tr class="tb-odr-item">
                    <th>No</th>
                    <th>Kode Outlet</th>
                    <th>Nama Outlet</th>
                    <th>Keterangan</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody class="tb-odr-body">
                <?php ($i = 1); ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="tb-odr-item">
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($data->kd_outlet); ?></td>
                    <td><?php echo e($data->nama_outlet); ?></td>
                    <td><?php echo e($data->keterangan); ?></td>
                    <?php if($data->status == 1): ?>
                    <td>Aktif</td>
                    <?php else: ?>
                    <td>Tidak Aktif</td>
                    <?php endif; ?>
                    <td>
                        <button type="submit" class="btn btn-warning" data-toggle="modal" data-target=".modal_input" onclick="ubahOutlet('<?php echo e($data->kd_outlet); ?>', '<?php echo e($data->nama_outlet); ?>', '<?php echo e($data->keterangan); ?>', '<?php echo e($data->status); ?>');">Ubah</button>
                        <a href="<?php echo e(url('deleteOutlet/')); ?>/<?php echo e($data->kd_outlet); ?>" onclick="if (confirm('Delete selected item?')){return true;}else{event.stopPropagation(); event.preventDefault();};"><button type="submit" class="btn btn-danger">Hapus</button></a>
                        <a href="<?php echo e(url('detailOutlet/')); ?>/<?php echo e($data->kd_outlet); ?>"><button type="submit" class="btn btn-success">Detail</button></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div><!-- .card-preview -->
</div><!-- nk-block -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    function setKodeOutlet() {
        $("#nama_outlet").val("");
        $("#keterangan").val("");
        $('#status').removeAttr('checked');
        $.ajax({
            type:'GET',
            url:'/api/getKodeOutlet',
            headers: {
                "Accept":"application/json",
                "Authorization":"Bearer <?php echo e(Auth::user()->api_token); ?>"
            },
            success:function(data){
                $("input[name=kd_outlet]").val(data);
            }
        });
    }

    function ubahOutlet($a, $b, $c, $d) {
        $('#link_url').attr('action', '<?php echo e(url('/ubahOutlet')); ?>');
        $("#kd_outlet").val($a);
        $("#nama_outlet").val($b);
        $("#keterangan").val($c);
        if ($d == 1) {
            $('#status').attr('checked', 'checked');
        } else {
            $('#status').removeAttr('checked');
        }
    }

    // function alert($kd_outlet) {
    //     var checkstr =  confirm('Apakah Anda yakin untuk menghapus?');
    //     if(checkstr == true){
    //         $.ajax({
    //             type:'GET',
    //             url:'/deleteOutlet/{$kd_outlet}',
    //             success:function(){
    //                 location.reload();
    //             }
    //         });       
    //     }else{
    //         return false;
    //     }
    // }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KANTOR\WEB\larisso_web\resources\views/outlet/index.blade.php ENDPATH**/ ?>