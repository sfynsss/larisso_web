<?php $__env->startComponent('mail::message'); ?>
# Hai <?php echo e($name); ?>


Terimakasih telah melakukan pendaftaran di Larisso Apps <br>
Kode aktivasi Anda 

<h1><?php echo e($token); ?></h1>

Terimakasih,<br>
Larisso Grup
<?php echo $__env->renderComponent(); ?><?php /**PATH D:\A\larisso_web\resources\views/Email/emailActivation.blade.php ENDPATH**/ ?>