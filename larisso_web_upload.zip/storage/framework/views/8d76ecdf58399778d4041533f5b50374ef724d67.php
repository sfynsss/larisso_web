<?php $__env->startComponent('mail::message'); ?>
# Hai <?php echo e($name); ?>


Terimakasih telah melakukan pendaftaran di Senyum Apps
Silahkan klik link di bawah mengaktifkan akun Anda

<?php $__env->startComponent('mail::button', ['url' => url('auth/activate')."?token=".$token ]); ?>
Aktifkan Akun Anda
<?php echo $__env->renderComponent(); ?>

Terimakasih,<br>
Senyum Media
<?php echo $__env->renderComponent(); ?><?php /**PATH D:\Kantor\SISTEM\SENYUM_VOUCHER\senyum_api\resources\views/Email/emailActivation.blade.php ENDPATH**/ ?>