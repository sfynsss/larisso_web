<!-- Large modal -->
<div class="modal fade modal_edit" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-top modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel">Data Barang</h4>
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="card-inner">
          <table class="datatable-init table">
            <thead>
              <tr>
                <th>No</th>
                <th>Kode Barang</th>
                <th>Nama Barang</th>
                <th>Stok</th>
                <th>Harga Jual</th>
                
                
              </tr>
            </thead>
            <tbody>
              <?php ($i = 1); ?>
              <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr ondblclick="tambahDetail('<?php echo e($mst->NO_ENT); ?>','<?php echo e($data->kd_brg); ?>', '<?php echo e($data->nm_brg); ?>', '<?php echo e($data->satuan1); ?>', '<?php echo e($data->harga_jl); ?>');">
                <td><?php echo e($i++); ?></td>
                <td><?php echo e($data->kd_brg); ?></td>
                <td><?php echo e($data->nm_brg); ?></td>
                <td><?php echo e($data->stok); ?></td>
                
                <td>Rp. <?php echo number_format($data->harga_jl, 0, ',', '.'); ?></td>
                
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div><?php /**PATH D:\KANTOR\WEB\larisso_web\resources\views/penjualan/popUpBarang.blade.php ENDPATH**/ ?>