<?php $__env->startSection('content'); ?>
<?php echo $__env->make('Penawaran.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="nk-block nk-block-lg">
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title">Data Penawaran</h3>
            </div><!-- .nk-block-head-content -->
            <div class="nk-block-head-content">
                <div class="toggle-wrap nk-block-tools-toggle">
                    <button type="button" class="btn btn-primary float-right" data-toggle="modal"  data-target=".bs-example-modal-lg">TAMBAH DATA</button> &nbsp
                    
                </div>
            </div><!-- .nk-block-head-content -->
        </div><!-- .nk-block-between -->
    </div><!-- .nk-block-head -->
    <div class="card card-bordered card-preview">
        <table class="table table-orders">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">ID Penawaran</th>
                    <th scope="col">Nama Penawaran</th>
                    <th scope="col">Gambar</th>
                </tr>
            </thead>
            <tbody class="tb-odr-body">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="tb-odr-item">
                    <td><?php echo e($data->id_penawaran); ?></td>
                    <td><?php echo e($data->penawaran); ?></td>
                    <td>
                      <?php if($data->gambar == ""): ?>
          						<span class="badge badge-danger">Data Kosong</span>
          						<?php else: ?>
          						<img src="<?php echo e(asset('storage')); ?>/<?php echo e($data->gambar); ?>" width="200" height="75">
          						<?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div><!-- .card-preview -->
</div><!-- nk-block -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/larisso_web/resources/views/Penawaran/penawaran.blade.php ENDPATH**/ ?>