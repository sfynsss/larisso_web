<?php echo e($slot); ?>

<?php /**PATH /var/www/html/larisso_web/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>