[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH D:\A\larisso_web\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>