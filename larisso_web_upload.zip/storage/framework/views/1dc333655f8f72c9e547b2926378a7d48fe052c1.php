<?php $__env->startComponent('mail::message'); ?>
<h1><b><center>Lupa password SenyumApps?</center></b></h1>
<br>

Kami mengirimkan email ini karena kamu meminta penggantian password SenyumApps. 
Klik tombol di bawah ini untuk mengganti password :
<br>

<?php $__env->startComponent('mail::button', ['url' => url('auth/forgetPassword')."?token=".$token."&email=".$email]); ?>
Ganti Password
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
Senyum Media
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\Kantor\SISTEM\SENYUM_VOUCHER\senyum_api\resources\views/Email/forgetPassword.blade.php ENDPATH**/ ?>