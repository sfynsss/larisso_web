<tr>
    <td class="header">
        <a href="<?php echo e($url); ?>">
            Senyum Media
        </a>
    </td>
</tr>
<?php /**PATH D:\Kantor\SISTEM\SENYUM_VOUCHER\senyum_api\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>