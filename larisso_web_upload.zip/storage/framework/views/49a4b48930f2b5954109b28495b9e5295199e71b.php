<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-body">

        <div class="row">
            <div class="col-md-8"><h4 class="card-title">Data Notification</h4></div>
            <div class="col-md-4 form-group">
                <button type="button" class="btn btn-primary float-right" data-toggle="modal"  data-target=".bs-example-modal-lg">TAMBAH DATA</button>
            </div>
        </div>


        <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
            <div class="modal-dialog modal-lg">
                <form action="<?php echo e(url('/notifGlobal')); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="myLargeModalLabel">Form Notifikasi</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        </div>
                        <div class="modal-body">
                            <div class="card-body">
                                <div class="form-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label class="control-label text-left">Judul</label>
                                            <div class="form-group row">
                                                <div class="col-md-12">
                                                    <input type="text" class="form-control" name="title" id="title">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Gambar</label>
                                                <input type="file" class="form-control" name="gambar" id="gambar" accept="image/*">
                                            </div>
                                        </div>
                                        <!--/span-->
                                        <!--/row-->
                                    </div>
                                    <!--/row-->
                                    <div class="row">
                                        <div class="col-md-12">
                                            <label class="control-label text-left">Rincian Pesan</label>
                                            <div class="form-group row">
                                                <div class="col-md-12">
                                                    <textarea class="form-control" name="notif" id="notif"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <!--/span-->
                                    </div>
                                    <!--/row-->
                                    <div class="row">
                                        <div class="col-md-12">
                                            <label class="control-label text-left">Pilih Target</label>
                                            <div class="form-group row">
                                                <div class="col-md-12">
                                                    <select id="user" name="user[]" multiple style="width: 100%;">
                                                        <option value="semua">Semua</option>
                                                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($user->KD_CUST); ?>"><?php echo e($user->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <!--/span-->
                                    </div>
                                    <!--/row-->
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger waves-effect text-left" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-success waves-effect text-left" onclick="simpan();">Submit</button>
                        </div>
                    </div>
                </form>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>

        <div class="table-responsive m-t-40">
            <table id="myTable" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Judul</th>
                        <th>Notif</th>
                        <th>Gambar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php ($no = 1); ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($no++); ?></td>
                        <td><?php echo e($data->judul); ?></td>
                        <td><?php echo e($data->notif); ?></td>
                        <td><img class="logo-data" src="<?php echo e(asset('storage')); ?>/<?php echo e($data->gambar); ?>"  width="300" height="100"></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>

    $(document).ready(function() {
        $("#user").select2();
    });

    function setKdCust() {
        var kategori = $("select[name=kategori]").val();
        var cabang = $("select[name=cabang]").val();
        if (kategori == "Select an Option" || cabang == "Select an Option") {
        } else {
            $.ajax({
             type:'POST',
             url:'/api/getKodeCust',
             data:{kategori:kategori, cabang:cabang},
             headers: {
                "Accept":"application/json",
                "Authorization":"Bearer <?php echo e(Auth::user()->api_token); ?>"
            },
            success:function(data){
              $("input[name=kode_cust]").val(data);
          }
      });
        }
    }

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.attr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kantor\SISTEM\SENYUM_VOUCHER\senyum_api\resources\views/Notification/notif.blade.php ENDPATH**/ ?>