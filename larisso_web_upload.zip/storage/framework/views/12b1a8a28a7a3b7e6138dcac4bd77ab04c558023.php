<!DOCTYPE html>
<html lang="en">

<head>
  <title>Larisso</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!--===============================================================================================-->  
  <link rel="icon" type="image/png" href="<?php echo e(url('assets/login/images/icons/favicon.ico')); ?>"/>
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/login/vendor/bootstrap/css/bootstrap.min.css')); ?>">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/login/fonts/font-awesome-4.7.0/css/font-awesome.min.css')); ?>">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/login/vendor/animate/animate.css')); ?>">
  <!--===============================================================================================-->  
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/login/vendor/css-hamburgers/hamburgers.min.css')); ?>">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/login/vendor/select2/select2.min.css')); ?>">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/login/css/util.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/login/css/main.css')); ?>">
  <!--===============================================================================================-->
</head>

<body>
  <div class="limiter">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-8">
          <div class="card">
            <div class="card-header"><?php echo e(__('Reset Password')); ?></div>

            <div class="card-body">
              <form method="POST" action="<?php echo e(url('auth/gantiPassword')); ?>">
                <?php echo csrf_field(); ?>

                <input type="hidden" name="token" value="<?php echo e($token); ?>">

                <div class="form-group row">
                  <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                  <div class="col-md-6">
                    <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e($email ?? old('email')); ?>" required autofocus>

                    <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                    <?php endif; ?>
                  </div>
                </div>

                <div class="form-group row">
                  <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                  <div class="col-md-6">
                    <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                    <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                    <?php endif; ?>
                  </div>
                </div>

                <div class="form-group row">
                  <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

                  <div class="col-md-6">
                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                  </div>
                </div>

                <div class="form-group row mb-0">
                  <div class="col-md-6 offset-md-4">
                    <button type="submit" class="btn btn-primary">
                      <?php echo e(__('Reset Password')); ?>

                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--===============================================================================================-->  
  <script src="<?php echo e(url('assets/login/vendor/jquery/jquery-3.2.1.min.js')); ?>"></script>
  <!--===============================================================================================-->
  <script src="<?php echo e(url('assets/login/vendor/bootstrap/js/popper.js')); ?>"></script>
  <script src="<?php echo e(url('assets/login/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
  <!--===============================================================================================-->
  <script src="<?php echo e(url('assets/login/vendor/select2/select2.min.js')); ?>"></script>
  <!--===============================================================================================-->
  <script src="<?php echo e(url('assets/login/vendor/tilt/tilt.jquery.min.js')); ?>"></script>
  <script >
    $('.js-tilt').tilt({
      scale: 1.1
    })
  </script>
  <!--===============================================================================================-->
  <script src="<?php echo e(url('assets/login/js/main.js')); ?>"></script>

</body>

</html><?php /**PATH D:\KANTOR\WEB\larisso_web\resources\views/auth/reset_password.blade.php ENDPATH**/ ?>