<?php echo e($slot); ?>

<?php /**PATH D:\A\larisso_web\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>