<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-body">
        
        <div class="row">
            <div class="col-md-8"><h4 class="card-title">Data Cabang</h4></div>
            <div class="col-md-4 form-group">
                
                    <button type="button" class="btn btn-primary float-right" data-toggle="modal"  data-target=".bs-example-modal-lg">TAMBAH DATA</button>
                
            </div>
        </div>


        <div class="modal fade bs-example-modal-lg" id="modalku" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
            <div class="modal-dialog modal-lg">
                <form action="<?php echo e(url('/tambahCabang')); ?>" method="post" id="link_url" class="form-horizontal">
                    <?php echo e(csrf_field()); ?>

                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="myLargeModalLabel">Form Cabang</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        </div>
                        <div class="modal-body">
                            <div class="card-body">
                                <div class="form-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="control-label text-left col-md-4">Nama Cabang</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" name="nama_cabang" id="nama_cabang" required >
                                                </div>
                                            </div>
                                        </div>
                                        <!--/span-->
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="control-label text-left col-md-4">Alamat Cabang</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" required name="alamat_cabang" id="alamat_cabang">
                                                </div>
                                            </div>
                                        </div>
                                        <!--/span-->
                                    </div>
                                    <!--/row-->
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger waves-effect text-left" data-dismiss="modal" onclick="clear();">Close</button>
                            <button type="submit" class="btn btn-success waves-effect text-left">Submit</button>
                        </div>
                    </div>
                </form>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>

        <div class="table-responsive m-t-40">
            <table id="myTable" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Cabang</th>
                        <th>Alamat</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php ($i = 1); ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($data->cabang); ?></td>
                        <td><?php echo e($data->alamat_cabang); ?></td>
                        <td>
                            <a class="label label-warning m-r-10" href="" data-toggle="modal"  data-target=".bs-example-modal-lg" onclick="setIsi('<?php echo e($data->cabang); ?>', '<?php echo e($data->alamat_cabang); ?>')"><i class="mdi mdi-pencil"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>

    $(document).ready(function() {
        $("#modalku").on('hidden.bs.modal', function() {
            $(this).find('form')[0].reset();
            $("#nama_cabang").attr("readonly", false);
        });
    });

    function setIsi($cabang, $alamat) {
        $("#nama_cabang").val($cabang);
        $("#nama_cabang").attr("readonly", true);
        $("#alamat_cabang").val($alamat);
        $("#link_url").attr("action", '<?php echo e(url('/updateCabang')); ?>');
    }  

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.attr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kantor\SISTEM\SENYUM_VOUCHER\senyum_api\resources\views/Cabang/cabang.blade.php ENDPATH**/ ?>