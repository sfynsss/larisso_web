<?php $__env->startComponent('mail::message'); ?>
<h1><b><center>Lupa password LarissoApps?</center></b></h1>
<br>

Kami mengirimkan email ini karena kamu meminta penggantian password LarissoApps. 
Klik tombol di bawah ini untuk mengganti password :
<br>

<?php $__env->startComponent('mail::button', ['url' => url('auth/forgetPassword')."?token=".$token."&email=".$email]); ?>
Ganti Password
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
Larisso Group
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\KANTOR\WEB\larisso_web\resources\views/Email/forgetPassword.blade.php ENDPATH**/ ?>