<?php echo e($slot); ?>

<?php /**PATH D:\Kantor\SISTEM\SENYUM_VOUCHER\senyum_api\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>