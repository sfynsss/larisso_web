

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('User.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="nk-block nk-block-lg">
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <?php if($status == "admin"): ?>
                <h3 class="nk-block-title page-title">Data Users Admin</h3>
                <?php elseif($status == "sales"): ?>
                <h3 class="nk-block-title page-title">Data Users Sales</h3>
                <?php endif; ?>
            </div><!-- .nk-block-head-content -->
            <div class="nk-block-head-content">
                <div class="toggle-wrap nk-block-tools-toggle">
                    <button type="button" class="btn btn-primary float-right" data-toggle="modal"  data-target=".bs-example-modal-lg" onclick="setTambah();">TAMBAH DATA</button> &nbsp
                    
                </div>
            </div><!-- .nk-block-head-content -->
        </div><!-- .nk-block-between -->
    </div><!-- .nk-block-head -->

    <div class="card card-bordered card-preview">
        <table class="table table-orders">
            <thead class="thead-dark">
                <tr>
                    <th>No</th>
                    <?php if($status == "sales"): ?>
                    <th>Kode Pegawai</th>
                    <?php endif; ?>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>No Telp</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php ($i = 1); ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <?php if($status == "sales"): ?>
                    <td><?php echo e($data->kd_peg); ?></td>
                    <?php endif; ?>
                    <td><?php echo e($data->name); ?></td>
                    <td><?php echo e($data->email); ?></td>
                    <td><?php echo e($data->no_telp); ?></td>
                    <td>
                        <button type="submit" class="btn btn-warning waves-effect text-left" onclick="setEdit('<?php echo e($data->kd_peg); ?>', '<?php echo e($data->name); ?>', '<?php echo e($data->email); ?>', '<?php echo e($data->tanggal_lahir); ?>', '<?php echo e($data->no_telp); ?>', '<?php echo e($data->alamat); ?>', '<?php echo e($data->cabang); ?>')" data-toggle="modal"  data-target=".bs-example-modal-lg">Edit</button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>

    function setEdit($kd_peg, $nama, $email, $tanggal_lahir, $no_telp, $alamat, $cabang) {
        $("#kd_peg").val($kd_peg);
        $("#name").val($nama);
        $("#email").val($email);
        $("#tgl_lahir").val($tanggal_lahir);
        $("#no_telp").val($no_telp);
        $("#alamat").val($alamat);
    }

    function setTambah() {
        $.ajax({
            type:'GET',
            url:'/api/getKdPeg',
            headers: {
                "Accept":"application/json",
                "Authorization":"Bearer <?php echo e(Auth::user()->api_token); ?>"
            },
            success:function(data){
              $("input[name=kd_peg]").val(data);
              $("#name").val("");
              $("#email").val("");
              $("#tgl_lahir").val("");
              $("#no_telp").val("");
              $("#alamat").val("");
              // alert(data);
          }
      });
    }
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/larisso_web/resources/views/User/user.blade.php ENDPATH**/ ?>