<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-body">
        
        <div class="row">
            <div class="col-md-8"><h4 class="card-title">Data Voucher</h4></div>
            <div class="col-md-4 form-group">
                <a href="<?php echo e(url('notifMultiDevice')); ?>"><button type="button" style="margin-left: 10px;" class="btn btn-primary float-right">NOTIFIKASI</button></a>
                <button type="button" class="btn btn-success float-right" onclick="validasi();">VALIDASI</button>
            </div>
        </div>

        <div class="table-responsive m-t-40">
            <table id="myTable" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode Voucher</th>
                        <th>Nama Voucher</th>
                        <th>Nama Customer</th>
                        <th>Nilai</th>
                        <th>Tgl Berlaku</th>
                        <th>Status</th>
                        <th>
                            <div class="custom-control custom-checkbox">
                              <input type="checkbox" class="custom-control-input" id="all" name="all" value="all" onchange="checkedAll(this);">
                              <label class="custom-control-label" for="all"></label>
                          </div>
                      </th>
                  </tr>
              </thead>
              <tbody>
                <?php ($i = 1); ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($data->kd_voucher); ?></td>
                    <td><?php echo e($data->nama_voucher); ?></td>
                    <td><?php echo e($data->NM_CUST); ?></td>
                    <td><?php echo e($data->nilai_voucher); ?></td>
                    <td><?php echo e($data->tgl_berlaku_2); ?></td>
                    <?php if($data->status_voucher == 'NON-AKTIF'): ?>
                    <td><a class="label label-warning m-r-10" href="#"><span>NON-AKTIF</span></a></td>
                    <?php elseif($data->status_voucher == 'AKTIF'): ?>
                    <td><a class="label label-info m-r-10" href="#"><span>AKTIF</span></a></td>
                    <?php elseif($data->status_voucher == 'DIGUNAKAN'): ?>
                    <td><a class="label label-success m-r-10" href="#"><span>DIGUNAKAN</span></a></td>
                    <?php endif; ?>
                    <td>
                        <div class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input" id="<?php echo e($data->kd_voucher); ?>" name="pilih" value="<?php echo e($data->kd_voucher); ?>">
                          <label class="custom-control-label" for="<?php echo e($data->kd_voucher); ?>"></label>
                      </div>
                  </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>

    function setKdCust() {
        var kategori = $("select[name=kategori]").val();
        var cabang = $("select[name=cabang]").val();
        if (kategori == "Select an Option" || cabang == "Select an Option") {
        } else {
            $.ajax({
               type:'POST',
               url:'/api/getKodeCust',
               data:{kategori:kategori, cabang:cabang},
               headers: {
                "Accept":"application/json",
                "Authorization":"Bearer <?php echo e(Auth::user()->api_token); ?>"
            },
            success:function(data){
              $("input[name=kode_cust]").val(data);
          }
      });
        }
    }

    function checkedAll(source) {
        var checkboxes = document.querySelectorAll('input[name="pilih"]');
        for (var i = 0; i < checkboxes.length; i++) {
            if (checkboxes[i] != source)
                checkboxes[i].checked = source.checked;
        }
    }

    function validasi() {
        var favorite = [];
        var data = "";
        $.each($("input[name='pilih']:checked"), function(){
            favorite.push($(this).val());
        });
        if (favorite != "") {
            data = favorite.join(";");
            $.ajax({
             type:'POST',
             url:'/api/validasi',
             data:{data:data},
             headers: {
                "Accept":"application/json",
                "Authorization":"Bearer <?php echo e(Auth::user()->api_token); ?>"
            }, 
            success:function(data){
                // location.reload(true);
                // alert(data);
                if (data == "berhasil") {
                    location.reload(true);
                } else {
                    alert(data);
                }
            }
        });
        } else {
            alert("pilih salah satu !!!");
        }
    }

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.attr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kantor\SISTEM\SENYUM_VOUCHER\senyum_api\resources\views/Voucher/eVoucher.blade.php ENDPATH**/ ?>