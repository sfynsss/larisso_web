<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-body">
        
        <div class="row">
            <div class="col-md-8"><h4 class="card-title">Data User</h4></div>
            <div class="col-md-4 form-group">
                
                    <button type="button" class="btn btn-primary float-right" data-toggle="modal"  data-target=".bs-example-modal-lg">TAMBAH DATA</button>
                
            </div>
        </div>


        <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
            <div class="modal-dialog modal-lg">
                <form action="<?php echo e(url('/tambahUser')); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="myLargeModalLabel">Form User</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        </div>
                        <div class="modal-body">
                            <div class="card-body">
                                <div class="form-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="control-label text-left col-md-4">Nama / Username</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" name="name" id="name" placeholder="Nama">
                                                </div>
                                            </div>
                                        </div>
                                        <!--/span-->
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="control-label text-left col-md-4">email</label>
                                                <div class="col-md-8">
                                                    <input type="email" class="form-control" name="email" id="email" placeholder="Email">
                                                </div>
                                            </div>
                                        </div>
                                        <!--/span-->
                                    </div>
                                    <!--/row-->
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="control-label text-left col-md-4">Tgl Lahir</label>
                                                <div class="col-md-8">
                                                    <input type="date" name="tgl_lahir" id="tgl_lahir" class="form-control" placeholder="Tgl Lahir">
                                                </div>
                                            </div>
                                        </div>
                                        <!--/span-->
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="control-label text-left col-md-4">No Telp</label>
                                                <div class="col-md-8">
                                                    <input type="number" name="no_telp" id="no_telp" class="form-control" placeholder="No Telp">
                                                </div>
                                            </div>
                                        </div>
                                        <!--/span-->
                                    </div>
                                    <!--/row-->
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="control-label text-left col-md-4">Alamat</label>
                                                <div class="col-md-8">
                                                    <input type="text" id="alamat" name="alamat" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="control-label text-left col-md-4">Password</label>
                                                <div class="col-md-8">
                                                    <input type="password" class="form-control" id="password" name="password">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/row-->
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group has-warning row">
                                                <label class="control-label text-left col-md-4">Pilih Cabang</label>
                                                <div class="col-md-8">
                                                    <select id="cabang" name="cabang" class="form-control custom-select">
                                                        <option style="display: none;">Select an Option</option>
                                                        <option value="01-Pusat">01-Pusat</option>
                                                        <option value="02-Trunojoyo">02-Trunojoyo</option>
                                                        <option value="03-Balung">03-Balung</option>
                                                        <option value="04-Rindang">04-Rindang</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <!--/span-->
                                    </div>
                                    <!--/row-->
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger waves-effect text-left" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-success waves-effect text-left">Submit</button>
                        </div>
                    </div>
                </form>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>

        <div class="table-responsive m-t-40">
            <table id="myTable" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>No Telp</th>
                        <th>Cabang</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php ($i = 1); ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($data->name); ?></td>
                        <td><?php echo e($data->email); ?></td>
                        <td><?php echo e($data->no_telp); ?></td>
                        <td><?php echo e($data->cabang); ?></td>
                        <td>
                            <button type="submit" class="btn btn-warning waves-effect text-left" onclick="setEdit('<?php echo e($data->name); ?>', '<?php echo e($data->email); ?>', '<?php echo e($data->tanggal_lahir); ?>', '<?php echo e($data->no_telp); ?>', '<?php echo e($data->alamat); ?>', '<?php echo e($data->cabang); ?>')" data-toggle="modal"  data-target=".bs-example-modal-lg">Edit</button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>

    function setEdit($nama, $email, $tanggal_lahir, $no_telp, $alamat, $cabang) {
        $("#name").val($nama);
        $("#email").val($email);
        $("#tgl_lahir").val($tanggal_lahir);
        $("#no_telp").val($no_telp);
        $("#alamat").val($alamat);
    }

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.attr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kantor\SISTEM\SENYUM_VOUCHER\senyum_api\resources\views/User/user.blade.php ENDPATH**/ ?>